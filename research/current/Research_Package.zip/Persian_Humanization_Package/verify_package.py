"""Verify a delivered research package without network or credentials."""
from pathlib import Path
import argparse,hashlib,json,subprocess,sys,tempfile

ROOT=Path(__file__).resolve().parent

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--hash-only',action='store_true');args=parser.parse_args()
    manifest=json.loads((ROOT/'PACKAGE_MANIFEST.json').read_text())
    for name,expected in manifest['files_sha256'].items():
        path=(ROOT/name).resolve()
        assert path.is_relative_to(ROOT) and path.is_file(),name
        with path.open('rb')as f:actual=hashlib.file_digest(f,'sha256').hexdigest()
        assert actual==expected,'File changed: '+name
    result={'hashes':'passed','files':len(manifest['files_sha256']),'new_api_calls':0}
    if not args.hash_only:
        import numpy  # Only external dependency; neither OpenAI nor a credential is loaded.
        project=ROOT/'persian_humanization_revision'
        with tempfile.TemporaryDirectory(prefix='persian-evidence-verify-')as temp:
            main_out=Path(temp)/'main';numeric_out=Path(temp)/'numeric'
            command=[sys.executable,'-B',str(project/'experiments/analyze_api_results.py'),'--directory',str(project/'experiments/api_study_v1'),'--secondary-directory',str(project/'experiments/api_study_secondary'),'--artifact-root',str(ROOT),'--out',str(main_out)]
            subprocess.run(command,check=True,stdout=subprocess.DEVNULL)
            command=[sys.executable,'-B',str(project/'experiments/analyze_numeric_results.py'),'--directory',str(project/'experiments/api_numeric_diagnostic_run'),'--artifact-root',str(ROOT),'--main-diagnostics',str(main_out/'response_diagnostics.csv'),'--out',str(numeric_out)]
            subprocess.run(command,check=True,stdout=subprocess.DEVNULL)
            a=json.loads((main_out/'analysis.json').read_text());b=json.loads((numeric_out/'analysis.json').read_text())
            assert a['status']==b['status']=='complete'
            assert a['validated_responses']==800 and b['validated_responses']==80
            assert a['query_groups']==100 and b['independent_source_groups']==10
            assert a['expected_unavailable_model_http404']==400 and a['unexpected_error_count']==b['recorded_errors']==0
            result.update(independent_analysis='passed',main_responses=800,numeric_responses=80,expected_unavailable_model_errors=400,human_ratings_created=0)
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
